﻿from distutils.core import setup

setup(
    name = "PythonTestModule",
    version = "1.1.0",
    py_modules=["printData"],
    author="yeachan",
    author_email = "yeachan10@naver.com",
    url = "www.greenjoa.com"
    )
